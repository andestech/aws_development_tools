VS_SHADER_ENTRYPOINT
--------------------

Specifies the name of the entry point for the shader of a ``.hlsl`` source
file.
