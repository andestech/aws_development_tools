OBJECT_OUTPUTS
--------------

Additional outputs for a Makefile rule.

Additional outputs created by compilation of this source file.  If any
of these outputs is missing the object will be recompiled.  This is
supported only on Makefile generators and will be ignored on other
generators.
