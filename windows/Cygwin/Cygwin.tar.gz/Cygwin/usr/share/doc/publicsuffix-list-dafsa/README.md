The Public Suffix List
======================

A "public suffix" is one under which Internet users can (or historically could)
directly register names. Some examples of public suffixes are .com, .co.uk and
pvt.k12.ma.us. The Public Suffix List is a list of all known public suffixes.

See https://publicsuffix.org/ for more information.

[![Build Status](https://travis-ci.org/publicsuffix/list.svg?branch=master)](https://travis-ci.org/publicsuffix/list)
